# Simply write a program that asks for a user’s First & last name. 
# If user does NOT exist, ask user for their top five (5) favorite movies with the following data points:  
# User’s first & last name, movie title, director, year released, IMDB start rating, Rotten Tomatoes star rating, and MPAA rating (PG, PG-13, R, etc.). 
# If user DOES exist, display their movie data.

# Gathers names for use in data later
firstName = input('Enter your first name : ')
lastName = input('Enter your last name: ')

# Makes userExists a boolean value, A.K.A. a true or false value
userExists = bool() 

# Checks if user's name is in the database
if userExists != True:
    print("Name does not exist in database. Please enter your 5 favorite movies: ")
    for i in range(5):                                                                      # Puts user into an input loop 5 times 
        title = input('Enter a movie title: ')
        director = input('Enter director(s) name: ')
        year = input('Enter release year: ')
        IMDB_rating = input('Enter IMDB rating: ')
        RT_rating = input('Enter Rotten-Tomatoes rating: ')
        ageRating = input('Enter MPAA rating: ')
        data = [firstName, lastName, title, director, year, IMDB_rating, RT_rating, ageRating] # Collects user inputs to be displayed in a list
    else:
        print(data)           # Displays user data at the end of the loop


